class TaskModel{
  String name;
  bool isComplete;
  TaskModel({required this.isComplete,required this.name});
}